package com.example.demo.services;

import com.example.demo.entities.Rol;
import com.example.demo.entities.Usuario;
import com.example.demo.repositories.RolRepository;
import com.example.demo.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RolRepository rolRepository;

    public List<Usuario> obtenerTodosLosUsuarios() {
        return usuarioRepository.findAll();
    }

    // Crear un nuevo usuario y asignarle un rol (por defecto: CLIENTE)
    public Usuario crearUsuarioConRolPorDefecto(Usuario usuario) {
        Rol rol = rolRepository.findByNombre("CLIENTE");
        if (rol == null) {
            throw new RuntimeException("Rol 'CLIENTE' no encontrado");
        }
        usuario.setRol(rol);
        return usuarioRepository.save(usuario);
    }

    // Crear usuario con rol personalizado
    public Usuario crearUsuarioConRol(Usuario usuario, String nombreRol) {
        Rol rol = rolRepository.findByNombre(nombreRol);
        if (rol == null) {
            throw new RuntimeException("Rol '" + nombreRol + "' no encontrado");
        }
        usuario.setRol(rol);
        return usuarioRepository.save(usuario);
    }

    // Obtener usuarios por nombre de rol
    public List<Usuario> obtenerUsuariosPorRol(String nombreRol) {
        Rol rol = rolRepository.findByNombre(nombreRol);
        if (rol == null) {
            throw new RuntimeException("Rol '" + nombreRol + "' no encontrado");
        }
        return usuarioRepository.findByRol(rol);
    }
}