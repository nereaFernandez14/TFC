package com.example.demo.repositories;

import com.example.demo.entities.Usuario;
import com.example.demo.entities.Rol;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    List<Usuario> findByRol(Rol rol);
}

