package com.example.demo.controller;

import com.example.demo.entities.Comentario;
import com.example.demo.entities.Restaurante;
import com.example.demo.entities.Usuario;
import com.example.demo.repositories.ComentarioRepository;
import com.example.demo.repositories.RestauranteRepository;
import com.example.demo.repositories.UsuarioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comentarios")
public class ComentarioController {

    @Autowired
    private ComentarioRepository comentarioRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RestauranteRepository restauranteRepository;

    @PostMapping
    public Comentario crearComentario(@RequestParam Long idCliente,
                                      @RequestParam Long idRestaurante,
                                      @RequestBody String contenido) {

        Usuario cliente = usuarioRepository.findById(idCliente).orElseThrow();  //Si no existe el cliente, lanzará una excepción
        Restaurante restaurante = restauranteRepository.findById(idRestaurante).orElseThrow(); //Si no existe el restaurante, lanzará una excepción

        Comentario comentario = new Comentario();
        comentario.setAutor(cliente);
        comentario.setRestaurante(restaurante);
        comentario.setContenido(contenido);

        return comentarioRepository.save(comentario);
    }

    @GetMapping
    public List<Comentario> getAllComentarios() {
        return comentarioRepository.findAll();
    }

    //Obtener comentarios del restaurante actual 
    @GetMapping("/mios")
    public List<Comentario> getMisComentarios(@RequestParam Long idUsuarioRestaurante) {
        // Buscar restaurante por usuario
        Restaurante restaurante = restauranteRepository.findByUsuarioId(idUsuarioRestaurante);
        return comentarioRepository.findByRestaurante(restaurante);
    }
}
