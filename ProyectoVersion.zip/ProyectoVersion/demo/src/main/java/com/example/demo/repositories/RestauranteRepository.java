package com.example.demo.repositories;

import com.example.demo.entities.Restaurante;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RestauranteRepository extends JpaRepository<Restaurante, Long> {
    Restaurante findByUsuarioId(Long idUsuario);
}
