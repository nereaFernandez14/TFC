package com.example.demo.controller;

import com.example.demo.entities.Usuario;
import com.example.demo.entities.Rol;
import com.example.demo.repositories.RolRepository;
import com.example.demo.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RolRepository rolRepository;

    // Obtener todos los usuarios
    @GetMapping
    public List<Usuario> getAllUsuarios() {
        return usuarioRepository.findAll();
    }

    // Crear nuevo usuario y asignarle un rol
    @PostMapping
    public Usuario crearUsuario(@RequestBody Usuario usuario) {
        Rol rol = rolRepository.findByNombre("CLIENTE"); // o "RESTAURANTE"
        usuario.setRol(rol);
        return usuarioRepository.save(usuario);
    }

    // Buscar usuarios por rol (opcional)
    @GetMapping("/por-rol/{nombreRol}")
    public List<Usuario> getUsuariosPorRol(@PathVariable String nombreRol) {
        Rol rol = rolRepository.findByNombre(nombreRol);
        return usuarioRepository.findByRol(rol);
    }
}
